# Diamond art sorting tray

A medium sorting tray with **14 valleys**, a tapered pour funnel and **open-top spout**, a removable tapered drop-in plug, and a rear-loading sliding lid. A **20 mm-deep flat shelf sits inside the rear of the tray, opposite the spout**, exactly level with the ridge tops.

**Revision 2 replaces the original friction plug with a plug captured by the lid.** The plug drops vertically into keyed, tapered grooves in the spout walls. The pocket shoulders resist forward withdrawal; the extended lid closes the top and prevents the plug lifting out. Reprint **all three main parts** for this revision; the original tray and lid do not fit the new plug system.

![CAD assembly preview](tray-preview.png)

![Spout and plug capture detail](spout-fit-preview.png)

## Print files

Load these three parts into **Bambu Studio** individually. Each is supplied as STL and **model-only 3MF**, in millimeters and already oriented with its intended printing face at Z=0. The 3MF files contain geometry and units; choose your own Bambu printer, nozzle, and filament presets. Import them as separate objects, not as parts of one assembled object.

| Part | STL | Model-only 3MF | Printed size (mm) |
|---|---|---|---|
| Tray | `print-files/01_tray.stl` | `print-files/01_tray.3mf` | 164 × 100 × 17.4 |
| Sliding lid | `print-files/02_sliding_lid.stl` | `print-files/02_sliding_lid.3mf` | 170.65 × 97.3 × 4.2 |
| Spout plug | `print-files/03_spout_plug.stl` | `print-files/03_spout_plug.3mf` | 12.15 × 13.4 × 6.9 |

The tray is 122 mm long before the funnel, 144 mm to the neck, and 164 mm including the spout. With the lid pull tab and plug installed, the assembled footprint is about 173.4 × 100 mm. Print the three pieces separately; a 180 mm bed fits each individual part. Bambu's A1 mini has a [180 × 180 × 180 mm build volume](https://cdn1.bambulab.com/documentation/quick-start-f507128172bdf/Quick%20start%20guide%20-%20A1%20mini-EN.pdf).

Bambu Studio supports STL and 3MF files; see the [Bambu Studio documentation](https://github.com/bambulab/BambuStudio/wiki/Command-Line-Usage). Use **File → Import** to load the models. Import STL in **millimeters, at 100% scale**. Extract the print-pack ZIP first and import the individual model files, choosing only one format per part. The revision-specific download is `diamond-art-tray-v2-print-pack.zip`; the generic print-pack ZIP contains the same updated files.

## Starting print settings

These are design-based starting settings, not a tested printer profile:

- PLA with your printer's matching filament preset.
- 0.4 mm nozzle; 0.20 mm layer height, or 0.16 mm for finer ridge surfaces.
- 3 wall loops, 4 top layers, 4 bottom layers; 15% infill.
- Supports off initially: the lid-track roof slopes are 45 degrees, and the spout is open above the pouring channel. Inspect the sliced preview before printing.
- Keep the supplied orientations. Tray: floor down. Lid: broad outer face down, with its rear stop and grip pointing upward. Plug: broad flat back face down, with the small pull tab pointing upward.
- Use your calibrated elephant-foot compensation so the plug's first layers and lid edges remain accurate. A brim can help if your bed adhesion requires it; keep brim remnants off mating edges.

## Fit tests and assembly

Optional files in `print-files/optional/`:

| File stem | Purpose |
|---|---|
| `fit_test_tray_tracks` | An 18 mm-long rear tray section containing both lid tracks. |
| `fit_test_lid` | A matching 25 mm-long rear lid section and pull tab. |
| `fit_test_spout` | A 12 mm-long nozzle section with the tapered plug pocket. |
| `fit_test_spout_lid` | Matching short lid section to check plug capture. |
| `plug_relaxed_fit` | A plug with more clearance if the normal plug prints too tight. |

Print the two rear track tests together, then slide the short lid into the rear opening. Their fit checks the same width and cross section as the full model. A short test cannot establish how a full-length lid will behave if it warps.

**Test the new retention system before printing the full tray:** print `fit_test_spout`, `fit_test_spout_lid`, and `03_spout_plug`. With the short lid off, lower the plug into the grooves from above, keeping its small pull tab pointing out of the spout. Slide the short lid in from the rear and align its rear edge with the rear edge of the test spout; the lid ends 0.35 mm before the front of the spout. The plug should resist lifting and forward withdrawal. Slide the short lid back to uncover the plug, then lift it out using the tab. The short lid has no travel stop, so center and position it manually.

Once printed, turn the lid so its flat outer face is upward and the stop flange is underneath. Feed its tapered nose into the tray from the shelf end and slide forward until the rear stop contacts the back wall. Pull the rear tab to remove it.

With the full lid retracted, **lower the plug vertically into the open slot**. The narrow end goes down and the pull tab faces forward. It uses clearance rather than an oversize friction fit; do not force it. Use the relaxed plug if needed. Close the lid to capture the plug and cover the spout. To pour, retract the lid at least 15 mm, lift the plug by its tab, then close the lid again if desired and tilt toward the funnel.

The lid uses approximately 0.35 mm of clearance at each lower tongue edge and 0.30 mm below the tongue. Plug top clearance below the closed lid is 0.20 mm; floor clearance is 0.15 mm. The sliding cover has a rear stop, with no latch. The plug closes the spout for loose diamond-art drills; physical retention and pouring still require a print test.

## Geometry and validation

- Fourteen 3.2 mm-wide flat valley bottoms, spaced on a 6.8 mm pitch.
- Thirteen interior ridges plus half ridges next to each side wall enclose those fourteen valleys.
- Floor: Z=1.8 mm. Ridge and shelf tops: Z=3.6 mm; ridge height above the floor is 1.8 mm.
- Full-width flat shelf: 20 mm deep, extending from the rear interior wall to the ridge field.
- Ridges taper down across their last 6 mm before the funnel.
- Wall thickness: nominally 2.4 mm. Wall height: 17.4 mm above the printing bed.
- Spout channel: 11.2 mm wide and open above it until the lid closes. Closed-lid internal height: 12.5 mm above the floor.
- Plug pocket: centered at X=161.2 mm, 4 mm thick along the spout; width tapers from 12.4 mm at the floor to 14 mm at the lid and stays open above it.
- Plug: 3.4 mm-thick gate, tapering from 11.8 mm wide at its bottom to 13.4 mm at its top, with a front-facing pull tab. Pocket shoulders key both sides into the spout walls.
- Lid cover thickness: 1.6 mm, with beveled track tongues; 4.2 mm total height at the rear grip.

`verification.json` records local checks on all eight exported parts: watertight meshes, consistent winding, positive volumes, one connected solid per part, STL and core-3MF round trips, build-volume bounds, and measured valley/ridge/shelf heights. The lid removal path is collision-free with the tray and seated plug at 172 positions. Both plug versions have zero seated interference and lift vertically without tray collision when the lid is removed. Moving a seated plug 1 mm forward or sideways meets the tray shoulders; lifting it 0.5 mm with the lid closed meets the lid. The spout's open top and the test fixture's capture geometry are also checked.

**Revision 2 has not been sliced in Bambu Studio or physically printed.** Use the included spout/plug/lid fit test before committing to the full print. The OpenSCAD source was generated from the same CAD operations; an OpenSCAD executable was unavailable for a separate render check.

## Editable CAD

`build_tray.py` is the parametric source of truth. Edit its dimension constants, then run:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python build_tray.py
```

Regeneration replaces the exports, preview, verification report, generated OpenSCAD source, and ZIP. Clearance and height constants must be adjusted together if changing track geometry. The valley count can be changed with `ROWS`; retain enough valley width for your drills.

`diamond-art-tray.scad` is a generated OpenSCAD CAD sketch. Set `part` to `assembly` or `exploded` to inspect it, or `tray`, `lid`, or `plug` for export in print orientation. Its numeric geometry is editable, but dimension changes are easiest in the Python source. The generated polyhedra use OpenSCAD's face winding convention, which is [opposite to STL](https://en.wikibooks.org/wiki/OpenSCAD_User_Manual/Primitive_Solids#polyhedron).
